package com.example.listmovies

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
