class BannerImages {
  static List<String> imageList = [
    "images/banner1.jpg",
    "images/banner2.jpg",
    "images/banner3.jpg",
    "images/banner4.jpg",
  ];
}
